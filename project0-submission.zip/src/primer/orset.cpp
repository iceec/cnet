#include "primer/orset.h"
#include <algorithm>
#include <string>
#include <vector>
#include "common/exception.h"
#include "fmt/format.h"

namespace bustub
{

  template <typename T>
  auto ORSet<T>::Contains(const T &elem) const -> bool
  {
    // TODO(student): Implement this
    // throw NotImplementedException("ORSet<T>::Contains is not implemented");
    if(del_map.count(elem)||elem_map.count(elem)==0)
          return false;
    return true;
    
  }

  template <typename T>
  void ORSet<T>::Add(const T &elem, uid_t uid)
  {
    // TODO(student): Implement this
    // throw NotImplementedException("ORSet<T>::Add is not implemented");
    add_map[elem] = uid;
    elem_map[elem] = uid;
    del_map.erase(elem);
  }

  template <typename T>
  void ORSet<T>::Remove(const T &elem)
  {
    // TODO(student): Implement this
    // throw NotImplementedException("ORSet<T>::Remove is not implemented");
    del_map.insert(elem);
    if(add_map.count(elem))
      add_map.erase(elem);
  }

  template <typename T>
  void ORSet<T>::Merge(const ORSet<T> &other)
  {
    // TODO(student): Implement this
    // throw NotImplementedException("ORSet<T>::Merge is not implemented");

    auto it = other.elem_map.begin();

    for (; it != other.elem_map.end(); ++it)
    {
      T  temp = it->first;
      uid_t tempid = it->second;
      if(other.add_map.count(temp))
      {
        del_map.erase(temp);
        if(elem_map.count(temp)==0)
          elem_map[temp]=tempid;
        continue;
      }

      if(other.del_map.count(temp))
      {
          if(add_map.count(temp)==0)
              elem_map.erase(temp);
          continue;
      }
      if(del_map.count(temp)||elem_map.count(temp))
            continue;
      elem_map[temp]=tempid;
    }
   
  }

  template <typename T>
  auto ORSet<T>::Elements() const -> std::vector<T>
  {
    // TODO(student): Implement this
    //throw NotImplementedException("ORSet<T>::Elements is not implemented");

       auto it = elem_map.begin();
    std::vector<T> ans;
    for (; it != elem_map.end(); ++it){
      if(del_map.count(it->first)==0)
        ans.push_back(it->first);
    }
    return ans;
  }

  template <typename T>
  auto ORSet<T>::ToString() const -> std::string
  {
    auto elements = Elements();
    std::sort(elements.begin(), elements.end());
    return fmt::format("{{{}}}", fmt::join(elements, ", "));
  }

  template class ORSet<int>;
  template class ORSet<std::string>;

} // namespace bustub
